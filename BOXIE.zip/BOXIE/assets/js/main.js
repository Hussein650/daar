let
    menuBtn = document.querySelector("header .menu-button"),
    navMenu = document.querySelector("header nav");

menuBtn.onclick = () => {
    if (navMenu.classList == "hidden")
        navMenu.classList = "";
    else
        navMenu.classList = "hidden";
};

let
    message = document.querySelector(".message"),
    messageColseBtn = document.querySelector(".message .close");

messageColseBtn.onclick = () => {
    message.classList.add("hidden");
};