let
    porductDescription = document.querySelectorAll(".product-card .description");

    porductDescription.forEach(dcr => {
        if (dcr.getAttribute("description").length >= 70) {
            dcr.innerText = dcr.getAttribute("description").slice(0, 70);
            dcr.setAttribute("textOfEnd", "...");
        } else {
            dcr.innerText = dcr.getAttribute("description");
            dcr.setAttribute("textOfEnd", ".");
        }
    });

let costs = document.querySelectorAll('.product-card .costs');

costs.forEach(cost => {
    if (cost.children.length < 2) {
        cost.children[0].classList.add("current-price");
    } else {
        cost.children[0].classList.add("old-price");
        cost.children[1].classList.add("current-price");
    }
});

let
    moreDetailsBtn = document.querySelectorAll(".product-details .more-details"),
    detailsAlertContainer = document.querySelector(".product-alert-details"),
    detailsAlert = document.querySelector(".product-alert-details .alert-body"),
    closeAlertbtn = document.querySelector(".product-alert-details .close-alert-btn");

moreDetailsBtn.forEach((btn, index) => {
    btn.onclick = () => {
        detailsAlert.innerText = porductDescription[index].getAttribute("description");
        detailsAlertContainer.classList.remove("hidden");
        document.body.classList.add("over-lay");
    };
});

closeAlertbtn.onclick = () => {
    detailsAlert.innerText = "";
    detailsAlertContainer.classList.add("hidden");
    document.body.classList.remove("over-lay");
};